package com.sandy.dictionary

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject

class ScrollerAdapter (val context: Context,val keys:ArrayList<String>,val values:ArrayList<String>):RecyclerView.Adapter<ScrollerAdapter.ScrollerViewHolder>(){

    class ScrollerViewHolder(val view:View):RecyclerView.ViewHolder(view){
        var type:TextView=view.findViewById(R.id.type)
        val desc:TextView=view.findViewById(R.id.desc)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScrollerViewHolder {
        val view=LayoutInflater.from(context).inflate(R.layout.single_row,parent,false)
        return ScrollerViewHolder(view)
    }

    override fun getItemCount(): Int {
        return keys.size
    }

    override fun onBindViewHolder(holder: ScrollerViewHolder, position: Int) {
        holder.type.text=keys[position]
        holder.desc.text=values[position]


    }

}