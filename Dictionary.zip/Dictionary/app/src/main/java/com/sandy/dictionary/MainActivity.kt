package com.sandy.dictionary

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.appcompat.widget.Toolbar
import androidx.core.content.getSystemService
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.sandy.dictionary.util.ConnectionManager

class MainActivity : AppCompatActivity() {

    lateinit var btnSearch:Button
    lateinit var etWord:TextView
    lateinit var scroller:RecyclerView
    lateinit var loading:RelativeLayout
    lateinit var toolbar: Toolbar
    lateinit var layoutManager:RecyclerView.LayoutManager
    lateinit var tvWord:TextView
    lateinit var pron:TextView
    lateinit var pronLabel:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnSearch=findViewById(R.id.btnSearch)
        etWord=findViewById(R.id.etWord)
        scroller=findViewById(R.id.scroller)
        toolbar=findViewById(R.id.toolbar)
        loading=findViewById(R.id.load)
        pron=findViewById(R.id.pron)
        pronLabel=findViewById(R.id.pronLabal)
        pronLabel.visibility=View.INVISIBLE
        tvWord=findViewById(R.id.tvWord)
        loading.visibility=View.INVISIBLE
        scroller.visibility=View.INVISIBLE
        layoutManager=LinearLayoutManager(this@MainActivity)

        setSupportActionBar(toolbar)


        btnSearch.setOnClickListener {

            val view=this.currentFocus
            view?.let {
                val inp=getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                inp?.hideSoftInputFromWindow(it.windowToken,0)
            }

            if(ConnectionManager().connectivityManager(this@MainActivity)) {
                loading.visibility=View.VISIBLE
                val word=etWord.text.toString()
                val queue=Volley.newRequestQueue(this@MainActivity)
                val url="https://wordsapiv1.p.rapidapi.com/words/$word"
                val requestObj=object :JsonObjectRequest(Request.Method.GET,url,null,Response.Listener {
                    //println("Respons is $it")

                    if(word==it.getString("word")) {
                        loading.visibility=View.INVISIBLE
                        scroller.visibility=View.VISIBLE
                        pronLabel.visibility=View.VISIBLE
                        tvWord.text=it.getString("word").toUpperCase()
                        pron.text=it.getJSONObject("pronunciation").getString("all")
                        val result=it.getJSONArray("results")
                        val adapter=TopRecyclerAdapter(this@MainActivity,result)
                        scroller.adapter=adapter
                        scroller.layoutManager=layoutManager

                    }
                    else{
                        Toast.makeText(this@MainActivity,"no matching word found",Toast.LENGTH_SHORT).show()
                    }



                },
                    Response.ErrorListener {
                        Toast.makeText(this@MainActivity,"no matching word found",Toast.LENGTH_SHORT).show()
                    }){
                    override fun getHeaders():MutableMap<String,String>
                    {
                        val headers=HashMap<String,String>()
                        headers["x-rapidapi-host"]="wordsapiv1.p.rapidapi.com"
                        headers["x-rapidapi-key"]="c119025ea2mshb5daa7cbb2dcb4ap108444jsn5cedb1ec3ec9"
                        return headers
                    }
                }
                queue.add(requestObj)

            }else{
                Toast.makeText(this@MainActivity,"NO connection",Toast.LENGTH_SHORT).show()
                val alert=AlertDialog.Builder(this@MainActivity)
                alert.setTitle("Error")
                alert.setMessage("Please connect to internet")
                alert.setPositiveButton("open settings"){
                    text,listner ->
                    val intent= Intent(Settings.ACTION_WIRELESS_SETTINGS)
                    startActivity(intent)
                    this@MainActivity.finish()
                }
                alert.setNegativeButton("Exit")
                {
                    text,listner -> this@MainActivity.finishAffinity()
                }
                alert.create().show()
            }
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater:MenuInflater=menuInflater
        inflater.inflate(R.menu.menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId==R.id.about)
        {
            val dialog=AlertDialog.Builder(this@MainActivity)
            dialog.setTitle("About")
            dialog.setMessage("This is an English to English online Dictionary.\n" +
                    "It is using WORDSAPI in the background word searching.\n"+
                    "Made by: Sanjib Samanta\n" +
                    "Email: sanjibsamanta442@gmail.com\n" +
                    "Happy Learning")

            dialog.setPositiveButton("OK"){
                    text,listner->{
            }
            }
            dialog.create()
            dialog.show()
        }
        return true
    }


}


