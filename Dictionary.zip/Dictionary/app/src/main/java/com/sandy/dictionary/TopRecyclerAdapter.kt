package com.sandy.dictionary

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray

class TopRecyclerAdapter (val context:Context,val jsonArray: JSONArray):RecyclerView.Adapter<TopRecyclerAdapter.TopRecyclerViewholder>(){

    class TopRecyclerViewholder(val view: View):RecyclerView.ViewHolder(view){
        val topRecycler:RecyclerView=view.findViewById(R.id.topRecycler)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TopRecyclerViewholder {
        val view=LayoutInflater.from(context).inflate(R.layout.top_recycler,parent,false)
        return TopRecyclerViewholder(view)
    }

    override fun getItemCount(): Int {
        return jsonArray.length()
    }

    override fun onBindViewHolder(holder: TopRecyclerViewholder, position: Int) {
        val layoutManager=LinearLayoutManager(context)
        val obj=jsonArray.getJSONObject(position)
        val keys=obj.keys()
        val keyList= arrayListOf<String>()
        val valueList= arrayListOf<String>()
        for (key in keys)
        {
            keyList.add(key)
            valueList.add(obj.getString(key))
        }
        val adaptor=ScrollerAdapter(context,keyList,valueList)
        holder.topRecycler.adapter=adaptor
        holder.topRecycler.layoutManager=layoutManager
    }
}