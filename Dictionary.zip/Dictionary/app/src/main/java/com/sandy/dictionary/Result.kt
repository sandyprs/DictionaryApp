package com.sandy.dictionary

data class Result(
    val def:String,
    val partsOfSpeech:String,
    val synonyme:ArrayList<String>,
    val typeOf:String
)